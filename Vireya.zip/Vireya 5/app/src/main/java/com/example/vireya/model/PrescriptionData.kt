package com.example.vireya.model

data class PrescriptionData(
    val name: String,
    val time: String,
    val tips: String,
    val days: String,
    val duration: String
)
